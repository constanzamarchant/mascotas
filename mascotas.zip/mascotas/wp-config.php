<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

define( 'WP_DEBUG', true );

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'mascotas' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '$KS|6DxCcpZk.92pu)9xMR-)^wT@wPtP#eI+jQ>ip[{:a=&A;v0Q}gh HK2RFXc&' );
define( 'SECURE_AUTH_KEY',  '7<OTon^II(diXJ+/pS.yld|ua6#Ju0`].3lX0Ra2Iv~UvxZSp5rq+omE@n_T~k3/' );
define( 'LOGGED_IN_KEY',    '1KiU!pWfi7FYz~^Mqc|BIX3#=,D1}M#wrE}ilImp%LOyK]FdG>igqSu9>AOo(9*`' );
define( 'NONCE_KEY',        'vPGg#6oaB@222Mc#d>E;.I~=kWHDUVhLH26G&aM;DHk)RTdJ4K?h*Es4.MaXnBS ' );
define( 'AUTH_SALT',        'Q=U:]Fn4`~C3r|E-_2rS1.,%9WJ~!up%. GHkpk5u9%{yL@Os(lG#Cw+IQ08GjAJ' );
define( 'SECURE_AUTH_SALT', 'T`4Px)o${/gupM0T)Zubx6;d?gN`j+fN%r@{iv$p+)e{qwo$he#6/ D*=>q`v&sn' );
define( 'LOGGED_IN_SALT',   '1rv0nl 06TVsndfaqKlpb..c2Ay4@k^YPK(_w_6#._a:-ARnWH#@N<U 5v.t)?oE' );
define( 'NONCE_SALT',       'vob*rw0663?2|SA{);LNE)xO;>vOD^|o~:u%Ti=2l,#Ux{mPQ#:P`2nH^:3ED|Uk' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'dl_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
